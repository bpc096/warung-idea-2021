<template>
  <div class="cool">
    TESTING HALO GUYS
  </div>
</template>

<script>
export default {
  name: 'HaloGuys',
}
</script>

<style lang="less" scoped>
.cool {
  color: salmon;
}
</style>