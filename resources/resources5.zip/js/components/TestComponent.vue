<template>
  <div class="test-wrapper">
    <h1>This is test component</h1>
  </div>
</template>

<script>
export default {
  name: 'TestComponent',
  
}
</script>

<style lang="less" scoped>
.test-wrapper {
  color: pink;
  background-color: lemonchiffon;
}
</style>>
