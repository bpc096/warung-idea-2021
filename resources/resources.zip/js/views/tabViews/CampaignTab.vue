<template>
  <div class="wrap-campaign-tab">
    <div class="background-section">
      <div class="background-title">
        Background Project
      </div>
      <div class="background-content">
       {{ projectDesc }}
      </div>
    </div>
    <div class="design-plan-section">
      <div class="design-plan-title">
        Project Design & Plan
      </div>
      <div class="design-plan-content">
        Lorem ipsum, dolor sit amet consectetur adipisicing elit. Ab a consequatur sint hic fuga quidem repellendus assumenda tempora odit molestiae voluptatibus eos quod voluptate provident nobis rem cum error vitae amet eum ipsum, ipsam, reiciendis pariatur laudantium. Pariatur omnis magni mollitia veritatis incidunt ullam dolor voluptatem illo facere earum! Non adipisci deserunt aliquid, laudantium nisi molestias ullam atque corrupti? Inventore architecto deleniti eveniet accusantium corrupti commodi obcaecati! Laboriosam a ut accusamus. Cum minus atque corrupti quisquam consectetur accusantium enim ab facere, sunt aliquid commodi nesciunt quod tempora, vel voluptate fugit. Maxime ea animi consequuntur saepe natus, officiis unde sint aperiam sequi. Suscipit accusamus, modi, iste aliquam magnam dolor commodi molestias vitae nobis sapiente ut, inventore placeat quisquam nihil architecto ipsum esse officiis. Vel laborum quidem sit cumque reiciendis impedit doloribus placeat earum, nihil, itaque eum excepturi neque eligendi rerum blanditiis natus voluptas laudantium quod adipisci numquam nemo provident fugit deleniti. Nihil quos aut pariatur molestias, eos natus! Rem aut dolorum enim praesentium illo consequuntur quas reiciendis minus quibusdam dolore modi, sed illum nam iusto quaerat possimus? Voluptate ea rem nobis, quos illum ratione tempore sed totam, ipsa, iure at praesentium pariatur quibusdam accusantium? Voluptas, tempora? Architecto saepe repudiandae veniam molestias.
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'CampaignTab',
  props: {
    projectDesc: {
      type: String,
      default: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Beatae obcaecati esse, culpa dolor tempora consequuntur quisquam corporis nesciunt vel adipisci laboriosam optio ratione maxime, quod reprehenderit commodi laudantium. Ut vero illum ipsa porro ratione officia corporis, delectus voluptatibus debitis perspiciatis aperiam omnis quo corrupti earum expedita quae, impedit reprehenderit? Illo nemo, inventore laboriosam sit tempora in quisquam voluptates sunt ratione numquam delectus facere magnam quibusdam quo nulla, obcaecati perferendis facilis aperiam accusantium soluta explicabo. Autem nihil explicabo quos ea, repellat doloremque itaque ipsam consectetur asperiores ab quae, totam magni doloribus nobis vitae labore nulla fugit dolorem officiis a! Vitae, ad!'
    }
  }
}
</script>

<style lang="less" scoped>
.wrap-campaign-tab{
  height: 70vh;
  text-align: left;
  padding: 0 5rem;

  .background-section {
    margin: 2rem 0;
    .background-title {
      font-size: 30px;
      font-weight: bold;
    }
  }

  .design-plan-section {
    margin: 2rem 0;
    .design-plan-title {
      font-size: 30px;
      font-weight: bold;
    }
  }



}
</style>
