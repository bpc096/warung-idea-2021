<template>
  <div class="wrap-update-tab">
    <div class="update-card">
      <div class="title-update">
        Lorem ipsum dolor sit amet.
      </div>
      <div class="content-update">
        Lorem ipsum dolor sit amet consectetur, adipisicing elit. Cupiditate, saepe reiciendis exercitationem, voluptas ipsam, rerum quam omnis adipisci quia quisquam ducimus veritatis. Natus aut dignissimos esse ad odit, dolorum, maxime nemo nam qui excepturi ducimus, corrupti ullam minima quibusdam quas ratione expedita tempore rem? Ipsa dolor excepturi, dolorem tempore doloribus eos! Similique nemo ex perferendis eligendi, at, quibusdam doloribus totam mollitia excepturi voluptas vitae deserunt suscipit dolor rem ratione ad veritatis iusto corporis dicta in maxime enim ipsam quam? Obcaecati, aperiam alias unde fugit quidem quasi quia dolorum dicta officia! Magnam, laudantium! Exercitationem eaque velit impedit doloremque. Odit, doloribus culpa.
      </div>
    </div>
    <div class="update-card">
      <div class="title-update">
        Lorem ipsum dolor sit amet.
      </div>
      <div class="content-update">
        Lorem ipsum dolor sit amet consectetur, adipisicing elit. Cupiditate, saepe reiciendis exercitationem, voluptas ipsam, rerum quam omnis adipisci quia quisquam ducimus veritatis. Natus aut dignissimos esse ad odit, dolorum, maxime nemo nam qui excepturi ducimus, corrupti ullam minima quibusdam quas ratione expedita tempore rem? Ipsa dolor excepturi, dolorem tempore doloribus eos! Similique nemo ex perferendis eligendi, at, quibusdam doloribus totam mollitia excepturi voluptas vitae deserunt suscipit dolor rem ratione ad veritatis iusto corporis dicta in maxime enim ipsam quam? Obcaecati, aperiam alias unde fugit quidem quasi quia dolorum dicta officia! Magnam, laudantium! Exercitationem eaque velit impedit doloremque. Odit, doloribus culpa.
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'UpdateTab'
}
</script>

<style lang="less" scoped>
.wrap-update-tab{
  min-height: 70vh;
  display: flex;
  flex-direction: column;
  align-items: center;

  .update-card {
    border: 1px solid black;
    width: 60rem;
    height: 20rem;
    margin: 5rem 0;
    text-align: left;
    padding: 10px;

    .title-update {
      margin: 1rem 0;
      font-size: 30px;
      font-weight: bold;
    }
  }

}
</style>
